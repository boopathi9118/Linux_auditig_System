#!/bin/bash

echo "    $(figlet Linux   auditing)"

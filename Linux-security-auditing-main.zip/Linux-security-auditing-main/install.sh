#!/bin/bash


chmod +x User_account.sh
chmod +x memory.sh
chmod +x master.sh
chmod +x File_system.sh
chmod +x File_permission.sh
chmod +x hardware.sh
chmod +x design.sh
chmod +x process.sh
chmod +x service.sh
chmod +x kernel.sh
chmod +x software.sh
chmod +x systemd.sh
chmod +x ssh.sh
